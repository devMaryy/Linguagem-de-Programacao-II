﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PLoops
{
    public partial class frmExercício1 : Form
    {
        public frmExercício1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //BOTÃO ESPAÇO EM BRANCO
            int i,qtdeespaço=0;
            for(i=0; i<rchtxtFrase.Text.Length; i++)
            {
                if (rchtxtFrase.Text[i] == ' ')
                {
                    qtdeespaço += 1;
                }
            }
            MessageBox.Show("A quantidade de espeços em branco é: "+ qtdeespaço);
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            //BOTÃO LETRA "R"
            string texto = rchtxtFrase.Text;
            int qtdeR = 0; 

            foreach (char r in texto)
            {
                if (r == 'r' || r == 'R')
                    qtdeR += 1;
            }

            MessageBox.Show("A quantidade de letras 'R' é: " + qtdeR);
        }

        private void btnPar_Click(object sender, EventArgs e)
        {
            //BOTÃO PARES DE LETRAS
            string texto = rchtxtFrase.Text;
            int pares = 0;

            for (int i = 1; i < texto.Length; i++)
            {
                if ((texto[i] == 'r' && texto[i - 1] == 'r') || (texto[i] == 's' && texto[i - 1] == 's'))
                {
                    pares++;
                    i++;
                }
            }

            if (pares == 0)
                MessageBox.Show("Não há pares de letras");
            else
                MessageBox.Show("A quantidade de letras pares é: " + pares);
        }
    }
}
