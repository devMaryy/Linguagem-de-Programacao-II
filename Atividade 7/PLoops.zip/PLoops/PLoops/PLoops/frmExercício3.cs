﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PLoops
{
    using System;
    using System.Linq;
    using System.Text.RegularExpressions;
    using System.Windows.Forms;
    public partial class frmExercício3 : Form
    {
        public frmExercício3()
        {
            InitializeComponent();
        }

        private void btnPalindromo_Click(object sender, EventArgs e)
        {
            string texto = txtPalindromo.Text;

            if(texto.Length > 50)
            {
                MessageBox.Show("Não pode ter mais de 50 caracteres");
                return;
            }

            string textoLimpo = RemoveAcentos(texto).ToUpper().Replace(" ", "");
            string textoInvertido = new string(textoLimpo.Reverse().ToArray());

            if (textoLimpo == textoInvertido)
            {
                MessageBox.Show("A sequência é um palíndromo.");
            }
            else
            {
                MessageBox.Show("A sequência não é um palíndromo.");
            }
        }



        //FUNÇÃO QUE REMOVE OS ACENTOS
        private string RemoveAcentos(string texto)
        {
            string textoComAcentos = texto.Normalize(NormalizationForm.FormD);
            Regex reg = new Regex("[^a-zA-Z0-9 ]");
            return reg.Replace(textoComAcentos, "");
        }
    }
}
