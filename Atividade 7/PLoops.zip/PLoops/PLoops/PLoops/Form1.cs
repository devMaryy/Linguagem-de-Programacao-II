﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PLoops
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Exercício1ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmExercício1>().Count() > 0)
            {
                MessageBox.Show("O form já existe");
                //DA ERRO SE O FORMS NÃO TEM NADA
                Application.OpenForms["frmExercício1"].BringToFront();

                //OU: Application.OpenForms["frmExercÍcio1"].Activate();
            }
            else
            {
                frmExercício1 obj1 = new frmExercício1();
                obj1.MdiParent = this;
                obj1.WindowState = FormWindowState.Maximized;
                obj1.Show();
            }
        }

        private void Exercício2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmExercício2>().Count() > 0)
            {
                MessageBox.Show("O form já existe");
                //DA ERRO SE O FORMS NÃO TEM NADA
                Application.OpenForms["frmExercício2"].BringToFront();

                //OU: Application.OpenForms["frmExercicio2"].Activate();
            }
            else
            {
                frmExercício2 obj2 = new frmExercício2();
                obj2.MdiParent = this;
                obj2.WindowState = FormWindowState.Maximized;
                obj2.Show();
            }
        }

        private void Exercício3ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmExercício3>().Count() > 0)
            {
                MessageBox.Show("O form já existe");
                //DA ERRO SE O FORMS NÃO TEM NADA
                Application.OpenForms["frmExercício3"].BringToFront();

                //OU: Application.OpenForms["frmExercício3"].Activate();
            }
            else
            {
                frmExercício3 obj3 = new frmExercício3();
                obj3.MdiParent = this;
                obj3.WindowState = FormWindowState.Maximized;
                obj3.Show();
            }
        }

        private void Exercício4ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmExercício4>().Count() > 0)
            {
                MessageBox.Show("O form já existe");
                //DA ERRO SE O FORMS NÃO TEM NADA
                Application.OpenForms["frmExercício4"].BringToFront();

                //OU: Application.OpenForms["frmExercício4"].Activate();
            }
            else
            {
                frmExercício4 obj4 = new frmExercício4();
                obj4.MdiParent = this;
                obj4.WindowState = FormWindowState.Maximized;
                obj4.Show();
            }
        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
