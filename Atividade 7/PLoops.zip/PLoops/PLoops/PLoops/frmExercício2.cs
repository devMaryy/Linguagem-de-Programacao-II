﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PLoops
{
    public partial class frmExercício2 : Form
    {
        public frmExercício2()
        {
            InitializeComponent();
        }

        private void btnCalcH_Click(object sender, EventArgs e)
        {
            int num;

            if (int.TryParse(txtNum.Text, out num))
            {
                if (num > 0)
                {
                    double H = 0;

                    for (int i = 1; i <= num; i++)
                    {
                        H += 1.0 / i;
                    }
                    MessageBox.Show("O valor de H é: " + H);
                }
                else
                {
                    MessageBox.Show("Digite um número inteiro maior que zero!");
                }
            }
            else
            {
                MessageBox.Show("Digite um número válido!");
            }
        }
    }
}
