﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PLoops
{
    public partial class frmExercício4 : Form
    {
        public frmExercício4()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            string nome = txtNome.Text;
            string matricula = txtMatricula.Text;
            double salario, gratificacao;
            int producao;

            if (!double.TryParse(txtSalario.Text, out salario))
            {
                MessageBox.Show("Insira um valor válido para o salário!");
                return;
            }

            if (!int.TryParse(txtProducao.Text, out producao))
            {
                MessageBox.Show("Insira um valor válido para a produção!");
                return;
            }

            if (!double.TryParse(txtGratificacao.Text, out gratificacao))
            {
                MessageBox.Show("Insira um valor válido para a gratificação!");
                return;
            }

            int D = 0;
            int C = 0;
            int B = 0;

            if (producao >= 150)
            {
                D = 1;
                C = 1;
                B = 1;
            }
            else if (producao >= 120)
            {
                C = 1;
                B = 1;
            }
            else if (producao >= 100)
            {
                B = 1;
            }

            double salarioBruto = salario + salario * (0.05 * B + 0.1 * C + 0.1 * D) + gratificacao;

            if (salarioBruto > 7000)
            {
                if (producao >= 150 && gratificacao > 0)
                {
                    MessageBox.Show("O salário bruto acima de R$ 7.000,00 está autorizado.\n\n" +
                        $"Funcionário: {nome}\nMatrícula: {matricula}\nSalário Bruto: R${salarioBruto:F2}");
                }
                else
                {
                    salarioBruto = 7000;
                    MessageBox.Show("O salário bruto foi ajustado para o máximo permitido: R$ 7.000,00.\n\n" +
                        $"Funcionário: {nome}\nMatrícula: {matricula}\nSalário Bruto: R${salarioBruto:F2}");
                }
            }
            else
            {
                MessageBox.Show($"Funcionário: {nome}\nMatrícula: {matricula}\nSalário Bruto: R${salarioBruto:F2}");
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNome.Clear();
            txtMatricula.Clear();
            txtProducao.Clear();
            txtSalario.Clear();
            txtGratificacao.Clear();
        }
    }
}

