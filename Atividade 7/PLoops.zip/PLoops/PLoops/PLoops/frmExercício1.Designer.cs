﻿namespace PLoops
{
    partial class frmExercício1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rchtxtFrase = new System.Windows.Forms.RichTextBox();
            this.btnEspaço = new System.Windows.Forms.Button();
            this.btnLetra = new System.Windows.Forms.Button();
            this.btnPar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // rchtxtFrase
            // 
            this.rchtxtFrase.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rchtxtFrase.Location = new System.Drawing.Point(74, 39);
            this.rchtxtFrase.MaxLength = 100;
            this.rchtxtFrase.Name = "rchtxtFrase";
            this.rchtxtFrase.Size = new System.Drawing.Size(642, 103);
            this.rchtxtFrase.TabIndex = 0;
            this.rchtxtFrase.Text = "";
            // 
            // btnEspaço
            // 
            this.btnEspaço.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEspaço.Location = new System.Drawing.Point(74, 296);
            this.btnEspaço.Name = "btnEspaço";
            this.btnEspaço.Size = new System.Drawing.Size(137, 64);
            this.btnEspaço.TabIndex = 1;
            this.btnEspaço.Text = "Espaço em branco ";
            this.btnEspaço.UseVisualStyleBackColor = true;
            this.btnEspaço.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnLetra
            // 
            this.btnLetra.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLetra.Location = new System.Drawing.Point(320, 296);
            this.btnLetra.Name = "btnLetra";
            this.btnLetra.Size = new System.Drawing.Size(137, 64);
            this.btnLetra.TabIndex = 2;
            this.btnLetra.Text = "Aparece a letra \"R\"";
            this.btnLetra.UseVisualStyleBackColor = true;
            this.btnLetra.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // btnPar
            // 
            this.btnPar.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPar.Location = new System.Drawing.Point(579, 296);
            this.btnPar.Name = "btnPar";
            this.btnPar.Size = new System.Drawing.Size(137, 64);
            this.btnPar.TabIndex = 3;
            this.btnPar.Text = "Par de letras";
            this.btnPar.UseVisualStyleBackColor = true;
            this.btnPar.Click += new System.EventHandler(this.btnPar_Click);
            // 
            // frmExercício1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnPar);
            this.Controls.Add(this.btnLetra);
            this.Controls.Add(this.btnEspaço);
            this.Controls.Add(this.rchtxtFrase);
            this.Name = "frmExercício1";
            this.Text = "frmExercício1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox rchtxtFrase;
        private System.Windows.Forms.Button btnEspaço;
        private System.Windows.Forms.Button btnLetra;
        private System.Windows.Forms.Button btnPar;
    }
}