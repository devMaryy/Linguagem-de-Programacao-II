﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PLoops
{
    public partial class frmExercício1 : Form
    {
        public frmExercício1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //BOTÃO ESPAÇO EM BRANCO (DEU CERTO!)
            int i,qtdeespaço=0;
            for(i=0; i<rchtxtFrase.Text.Length; i++)
            {
                if (rchtxtFrase.Text[i] == ' ')
                {
                    qtdeespaço += 1;
                }
            }
            MessageBox.Show("A quantidade de espeços em branco é: "+ qtde);
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            //BOTÃO LETRA "R"

            while (i = 0; i < rchtxtFrase.Text.Length; i++)
            {
                (rchtxtFrase.Text[i] == 'R')
            }

        }
    }
}
