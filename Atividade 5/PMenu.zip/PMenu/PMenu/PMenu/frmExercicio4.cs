﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMenu
{
    public partial class frmExercicio4 : Form
    {
        string texto;
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnContarNum_Click(object sender, EventArgs e)
        {
            int cont, tamanho, contnum;
            
            cont = 0;
            tamanho = rchtxtFrase.TextLength;
            contnum = 0;

            while (cont < tamanho)
            {
                if (char.IsNumber(rchtxtFrase.Text[cont]))
                {
                    contnum++;
                }

                cont++;
            }
            MessageBox.Show("O total de números que aparecem são: " + contnum);
        }

        private void btnEspaço_Click(object sender, EventArgs e)
        {
            texto = rchtxtFrase.Text;

            texto = texto.Trim();
            char[] vetor = texto.ToCharArray();
            int comprimento = texto.Length;

            for (int i = 0; i < comprimento; i++)
            {
                if (char.IsWhiteSpace(vetor[i]))
                {
                    i += 1;
                    MessageBox.Show("O primeiro espaço em branco que aparece está na posição " + i);
                    break;
                }
            }
        }

        private void btnContarLetras_Click(object sender, EventArgs e)
        {
            texto = rchtxtFrase.Text;

            char[] vetor = texto.ToCharArray();
            int contLetra = 0;

            foreach (char c in texto)
            {
                if (char.IsLetter(c))
                {
                    contLetra++;
                }
            }

            MessageBox.Show("O número total de letras é " + contLetra);
        }
    }
}
