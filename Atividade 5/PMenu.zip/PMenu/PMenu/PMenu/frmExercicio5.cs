﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMenu
{
    public partial class frmExercicio5 : Form
    {
        int numero1, numero2;
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void txtNumero2_Validated(object sender, EventArgs e)
        {
            if (!int.TryParse(txtNumero2.Text, out int numero2))
            {
                MessageBox.Show("Número inválido!");
                txtNumero2.Focus();
            }
        }

        private void btnSortear_Click(object sender, EventArgs e)
        {
            Random random = new Random();
            double sorteio;

            if (numero1 <= numero2)
            {
                sorteio = random.Next(numero1, numero2);
            }
            else
            {
                sorteio = random.Next(numero2, numero1);
            }
            if (numero1 > numero2)
            {
                MessageBox.Show("O número sorteado é " + sorteio + "\nO primeiro número não é menor que o segundo");
            }
            else if (numero1 < numero2)
            {
                MessageBox.Show("O número sorteado é " + sorteio + "\nO primeiro número é menor que o segundo");
            }
            else
            {
                MessageBox.Show("O número sorteado é " + sorteio + "\nO primeiro número é igual ao segundo");
            }
        }

        private void txtNumero1_Validated(object sender, EventArgs e)
        {
            if(!int.TryParse(txtNumero1.Text, out int numero1))
            {
                MessageBox.Show("Número inválido!");
                txtNumero1.Focus();
            }
        }
    }
}
