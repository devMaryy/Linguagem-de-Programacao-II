﻿namespace PMenu
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rchtxtFrase = new System.Windows.Forms.RichTextBox();
            this.btnContarNum = new System.Windows.Forms.Button();
            this.btnEspaço = new System.Windows.Forms.Button();
            this.btnContarLetras = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // rchtxtFrase
            // 
            this.rchtxtFrase.Location = new System.Drawing.Point(126, 58);
            this.rchtxtFrase.Name = "rchtxtFrase";
            this.rchtxtFrase.Size = new System.Drawing.Size(618, 215);
            this.rchtxtFrase.TabIndex = 0;
            this.rchtxtFrase.Text = "";
            // 
            // btnContarNum
            // 
            this.btnContarNum.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnContarNum.Location = new System.Drawing.Point(77, 448);
            this.btnContarNum.Name = "btnContarNum";
            this.btnContarNum.Size = new System.Drawing.Size(146, 69);
            this.btnContarNum.TabIndex = 1;
            this.btnContarNum.Text = "Contar Números";
            this.btnContarNum.UseVisualStyleBackColor = true;
            this.btnContarNum.Click += new System.EventHandler(this.btnContarNum_Click);
            // 
            // btnEspaço
            // 
            this.btnEspaço.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEspaço.Location = new System.Drawing.Point(351, 448);
            this.btnEspaço.Name = "btnEspaço";
            this.btnEspaço.Size = new System.Drawing.Size(146, 69);
            this.btnEspaço.TabIndex = 2;
            this.btnEspaço.Text = "1º espaço em branco";
            this.btnEspaço.UseVisualStyleBackColor = true;
            this.btnEspaço.Click += new System.EventHandler(this.btnEspaço_Click);
            // 
            // btnContarLetras
            // 
            this.btnContarLetras.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnContarLetras.Location = new System.Drawing.Point(635, 448);
            this.btnContarLetras.Name = "btnContarLetras";
            this.btnContarLetras.Size = new System.Drawing.Size(146, 69);
            this.btnContarLetras.TabIndex = 3;
            this.btnContarLetras.Text = "Contar Letras";
            this.btnContarLetras.UseVisualStyleBackColor = true;
            this.btnContarLetras.Click += new System.EventHandler(this.btnContarLetras_Click);
            // 
            // frmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(910, 635);
            this.Controls.Add(this.btnContarLetras);
            this.Controls.Add(this.btnEspaço);
            this.Controls.Add(this.btnContarNum);
            this.Controls.Add(this.rchtxtFrase);
            this.Name = "frmExercicio4";
            this.Text = "frmExercicio4";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox rchtxtFrase;
        private System.Windows.Forms.Button btnContarNum;
        private System.Windows.Forms.Button btnEspaço;
        private System.Windows.Forms.Button btnContarLetras;
    }
}