﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMenu
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnContarNum_Click(object sender, EventArgs e)
        {
            int cont, tamanho, contnum;
            
            cont = 0;
            tamanho = rchtxtFrase.TextLength;
            contnum = 0;

            while (cont < tamanho)
            {
                if (char.IsNumber(rchtxtFrase.Text[cont]))
                {
                    contnum++;
                }

                cont++;
            }
            MessageBox.Show("O total de números que aparecem são: " + contnum);
        }
    }
}
