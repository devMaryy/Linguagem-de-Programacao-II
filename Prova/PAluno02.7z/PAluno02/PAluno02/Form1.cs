﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Collections;


namespace PAluno02
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            double[,] notas = new double[2, 3];
            string aux = "";

            for (var aluno = 0; aluno < 2; aluno++)
            {
                for (var nota = 0; nota < 3; nota++)
                {
                    aux = Interaction.InputBox($"Digite a nota {nota + 1}: do aluno {aluno + 1}", "Entrada de dados");
                    if (!double.TryParse(aux, out notas[aluno, nota]))
                    {
                        MessageBox.Show("Número inválido!");
                        nota--;
                    }
                    else
                    {
                        if (notas[aluno, nota] < 0 || notas[aluno, nota] > 10)
                        {
                            MessageBox.Show("Número inválido! \n O número deve estar entre 0 e 10");
                            nota--;
                        }
                    }
                }
            }

            string resultado = ""; 
            double[] media = new double[2];
            double mediaG;


                for (var aluno = 0; aluno < 2; aluno++)
                {

                    media[aluno] = (notas[aluno, 0] + notas[aluno, 1] + notas[aluno, 2]) / 3;

                }
                for (var aluno = 0; aluno < 2; aluno++)
                {

                    lstbox.Items.Add("Aluno " + (aluno + 1)+ "\n" + " Professor 1: " + notas[aluno, 0].ToString("N2") + "\n"+ " Professor 2: " + notas[aluno, 1].ToString("N2") + "\n" + " Professor 3: " + notas[aluno, 2].ToString("N2") + "\n" + " Média: " + media[aluno].ToString("N2") + "\n");
                }
                    
                    

            mediaG = (media[0] + media[1]) / 2;
            resultado += mediaG.ToString("N2") + "\n";

            lstbox.Items.Add("-----------------------------------------------------------------------------");
            lstbox.Items.Add("Media geral: " + resultado);
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lstbox.Items.Clear();
        }
    } 
}
