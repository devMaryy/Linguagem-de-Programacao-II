﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PMatrizes
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            string[] nomes = new string[10];
            string[] vetor = new string[10];
            int[] tamanho = new int[10];
            string[] saida = new string[10];

            for (int i = 0; i < 10; i++)
            {
                nomes[i] = Interaction.InputBox($"Digite o {i + 1}º nome", "Entrada de dados");
                vetor[i] = nomes[i].Replace(" ", "");
                tamanho[i] = vetor[i].Length;
            }
            for (int i = 0; i < 10; i++)
            {
                saida[i] += "\nO nome: " + nomes[i] + " tem " + tamanho[i] + " caracteres" + "\n";
            }

            for (int i = 0; i < 10; i++)
            {
                lstbxNome.Items.Add(saida[i]);
            }
        }
    }
}
