﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PMatrizes
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            int[] nomes = new int[3];
            string auxiliar = "";

            for (int i = 0; i < 10; i++)
            {
                auxiliar = Interaction.InputBox("Digite o nome: ", "Entrada de dados");

                foreach (int x in nomes)
                {
                    auxiliar = auxiliar.Length;
                    MessageBox.Show(auxiliar);
                }


            }
            MessageBox.Show(auxiliar);
        }
    }
}
