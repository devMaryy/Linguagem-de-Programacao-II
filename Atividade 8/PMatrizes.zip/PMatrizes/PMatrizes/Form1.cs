﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualBasic;
using System.Windows.Forms;
using System.Collections;

namespace PMatrizes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnEx1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20]; //CRIANDO O VETOR
            string auxiliar = "";

            for (var i=0; i<20; i++)
            {
                auxiliar = Interaction.InputBox($"Digite o {i+1}º número:", "Entrada de dados");

                if(!int.TryParse(auxiliar, out vetor[i])) //Validando os números
                {
                    MessageBox.Show("Número inválido!");
                    i--;
                }
            }

            Array.Reverse(vetor);

            auxiliar = "";
            foreach (int x in vetor)
            {
                auxiliar += x + "\n";
                MessageBox.Show(auxiliar);
            }
        }

        private void btnEx2_Click(object sender, EventArgs e)
        {
            string auxiliar = "";

            ArrayList lista = new ArrayList() {"Ana", "André", "Débora", "Fátima", "João", "Janete", "Otávio", "Marcelo", "Pedro", "Thais" };
            lista.Remove("Otávio");

            foreach (string s in lista)
            {
                auxiliar += s + "\n";
                MessageBox.Show(auxiliar);
            }
        }

        private void btnEx3_Click(object sender, EventArgs e)
        {
            int num = 20;
            double[,] notas = new double[num, 3];
            string aux = "";
            
            for (var aluno=0; aluno<num; aluno++)
            {
                for (var nota=0; nota<3; nota++)
                {
                    aux = Interaction.InputBox($"Digite a nota {nota + 1}: do aluno {aluno + 1}", "Entrada de dados");
                    if(!double.TryParse(aux, out notas[aluno, nota]))
                    {
                        MessageBox.Show("Número inválido!");
                        nota--;
                    }
                    else
                    {
                        if (notas[aluno, nota] < 0 || notas[aluno, nota] > 10)
                        {
                            MessageBox.Show("Número inválido! \n O número deve estar entre 0 e 10");
                            nota--;
                        }
                    }
                }
            }
          
            string resultado = "";
            double[] media = new double[num];

            for (var aluno=0; aluno<num; aluno++)
            {

                media[aluno] = (notas[aluno, 0] + notas[aluno, 1] + notas[aluno, 2]) / 3;
                
            }
            for (var aluno = 0; aluno < num; aluno++)
            {

                resultado += "Aluno" + (aluno + 1)+ ":" + " Média: " + media[aluno].ToString("N2") + "\n";
            }
            MessageBox.Show(resultado);
        }

        private void btnEx4_Click(object sender, EventArgs e)
        {
            frmExercicio4 obj = new frmExercicio4();
            obj.Show();
        }

        private void btnEx5_Click(object sender, EventArgs e)
        {
            frmExercicio5 obj = new frmExercicio5();
            obj.Show();
        }
    }
}
