﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PClasses
{
    abstract internal class Empregado
    {
        private int matricula; //ATRIBUTOS
        private string nomeEmpregado;
        private DateTime dataEntradaEmpresa;

        public int Matricula //PROPRIEDADE    Observe a a letra esta maiúscula!
        {
            get { return matricula; }
            set { matricula = value; }
        }

        public string NomeEmpregado //PROPRIEDADE
        {
            get { return nomeEmpregado; }
            set { nomeEmpregado = value; }
        }

        public DateTime DataEntradaEmpresa //PROPRIEDADE
        {
            get { return dataEntradaEmpresa; }
            set { dataEntradaEmpresa = value; }
        }

        public virtual double TempoTrabalho() //"AUTORIZAÇÃO" PARA CRIAR OUTRA VERSÃO DO TEMPOTRABALHO
        {
            Double diasTrabalho;
            DateTime dataAtual = DateTime.Today;
            diasTrabalho = dataAtual.Subtract(dataEntradaEmpresa).TotalDays;
            return diasTrabalho;
        }
        public abstract Double SalarioBruto();




    }
}
